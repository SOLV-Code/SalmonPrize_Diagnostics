### This script can be used to process the model fittings results of individual and hierarchical models together, 
###     and find the overall best model for each river
library(ggplot2); library(plyr); library(this.path)
setwd(this.path::here())


### Read in data ###
all_dat = read.csv("data/processed_data.csv")

## Summary information for each river
popSummary = all_dat[!duplicated(all_dat$River),  c("System", "River", "Pop_id", "age_class_type", "yearStart", "nYearsData", "maxE")]


### Read in results ###
setwd(paste0(this.path::here(), "/results"))
res = do.call(rbind.fill, lapply(list.files(pattern = '\\.csv'), read.csv, header = TRUE))


### Find best model for each river (minimizes MAPE on test set)
popBestRes = aggregate(res$MAPEtest, by = list(res$Pop_id), min); colnames(popBestRes) = c("Pop_id" ,"bestMAPE")
res = merge(res, popBestRes)
res = merge(res, popSummary, by = "Pop_id")
bestres = subset(res, MAPEtest == bestMAPE)
summary(bestres$bestMAPE)
print(bestres[, c("Pop_id", "System", "River", "MAPEtest", "forecast2025")])
print(bestres[, c("Pop_id", "System", "River", "model_type", "E", "transform_type", "rho_model_type", "scale_type")])
print(bestres[, c("Pop_id", "System", "River", "retrospec2020forecast", "retrospec2021forecast", "retrospec2022forecast",
                  "retrospec2023forecast", "retrospec2024forecast")])


## Find all near optimal models
outsampR2_bestMods = list()
for(pop_i in unique(res$Pop_id)){
  outsampR2_popi = subset(res, Pop_id == pop_i)
  outsampR2_popi = outsampR2_popi[order(outsampR2_popi$MAPEtest),]
  best_MAPE = min(outsampR2_popi$MAPEtest)
  outsampR2_popi = subset(outsampR2_popi, MAPEtest <= 1.2*best_MAPE)
  outsampR2_bestMods[[pop_i]] = outsampR2_popi
  #print(outsampR2_popi[, c("Pop_id", "System", "River", "MAPEtest", "forecast2025", "model_type", "E", "transform_type")])
  #print(" ")
}
outsampR2_bestMods = do.call(rbind, outsampR2_bestMods)


## Make plots of retrospective forecasts
retrospec_forecasts = data.frame(River = rep(bestres$River, 5),
                            Year = c(rep(2020, 14), rep(2021, 14), rep(2022, 14), rep(2023, 14), rep(2024, 14)),
                            forecast = c(bestres$retrospec2020forecast, bestres$retrospec2021forecast, bestres$retrospec2022forecast, bestres$retrospec2023forecast, bestres$retrospec2024forecast))

system_plot = "Fraser River"
ggplot() + 
  geom_col(data = subset(all_dat, System == system_plot & ReturnYear >= 2020 & ReturnYear < 2025), aes(x = ReturnYear, y = Total_Returns, group = River)) +
  geom_point(data = subset(retrospec_forecasts, River %in% unique(subset(all_dat, System == system_plot)$River)), aes(x = Year, y = forecast, group = River), color = 'red') +
  facet_wrap(~River, scales = 'free') +
  labs(x = "Year", y = "Total Returns")





