### This script fits individual GPEDM model(s) for each of the fourteen rivers
## NOTE: in the following code, the age classes are named incorrectly (off by one year): "age 2" should be age 3,
##       "age 4 or greater" should be age 5 or greater, and so forth. This naming error does not affect model performance or results

library(GPEDM); library(ggplot2); library(foreach); library(this.path)
## GPEDM package: https://tanyalrogers.github.io/GPEDM/
setwd(this.path::here())

### Settings ###

## Primary model settings. Can include multiple options in a vector, and all combinations of model settings will be fit
# E: embedding dimension, aka how many years back should the lags of returns go? Can be 1, ..., 8
# model_type: the general structure of the model. Options include "indv_returns_byReturns", "indv_returns_byAges", "indv_ages_byAges"
#       indv_returns_byReturns: lags of total returns are used to predict total returns
#       indv_returns_byAges: lags of age-structured returns are used to predict total returns
#       indv_returns_byReturns: lags of age-structured returns are used to predict age-structured returns. Forecasts for each 
#                               age are then summed to get a forecast of total returns.
# transform: what data transformation should be applied? Options include "none", "log", "growth.rate" (i.e., ln[x_{t}/x_{t-1}]) 
# river: for which rivers should we fit models? For convenience, numbers are assigned to each river (1 = "Alagnak", 2 = "Egegik", etc.); options include 1, ..., 14

E_to_test = 1:8
model_type_to_test = c("indv_returns_byReturns", "indv_returns_byAges", "indv_ages_byAges")
transform_to_test = c("none", "log", "growth.rate") 
rivers_to_test = 1:14 

## other settings
test_set_size = 10  #How many years to include in the test set. More years will take longer
remove_data_before_year = 1952 #throw out data before this year
save_output = F   # save csv file of model performance results?


### Read in Data ###
all_dat = read.csv("data/processed_data.csv")

#Throw out earlier data?
all_dat = subset(all_dat, ReturnYear >= remove_data_before_year) 

## Summary information for each river
popSummary = all_dat[!duplicated(all_dat$River),  c("System", "River", "Pop_id", "age_class_type", "yearStart", "nYearsData", "maxE")]

log_transform_constant = all_dat$log_transform_constant[1]

## Results data frame
all_res = expand.grid(E = E_to_test, Pop_id = rivers_to_test, model_type = model_type_to_test, transform_type = transform_to_test)
all_res = merge(all_res, popSummary, by = "Pop_id")
all_res = subset(all_res, E <= maxE) #for pops with less data, remove E above sqrt(T), where T is time series length
all_res = all_res[order(all_res$Pop_id, all_res$model_type, all_res$E),]
all_res$runID = 1:nrow(all_res)

## Make lags
return_lags = makelags(all_dat, y = "Total_Returns", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
logreturn_lags = makelags(all_dat, y = "log_Total_Returns", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age3_lags = makelags(all_dat, y = "age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age4_lags = makelags(all_dat, y = "age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age2_less_lags = makelags(all_dat, y = "age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age3_less_lags = makelags(all_dat, y = "age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age4_plus_lags = makelags(all_dat, y = "age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age5_plus_lags = makelags(all_dat, y = "age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age3_lags = makelags(all_dat, y = "log_age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age4_lags = makelags(all_dat, y = "log_age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age2_less_lags = makelags(all_dat, y = "log_age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age3_less_lags = makelags(all_dat, y = "log_age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age4_plus_lags = makelags(all_dat, y = "log_age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age5_plus_lags = makelags(all_dat, y = "log_age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_lags = makelags(all_dat, y = "growth.rate", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age3_lags = makelags(all_dat, y = "growth.rate_age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age4_lags = makelags(all_dat, y = "growth.rate_age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age2_less_lags = makelags(all_dat, y = "growth.rate_age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age3_less_lags = makelags(all_dat, y = "growth.rate_age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age4_plus_lags = makelags(all_dat, y = "growth.rate_age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age5_plus_lags = makelags(all_dat, y = "growth.rate_age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")

all_dat = cbind(all_dat, return_lags, logreturn_lags, age3_lags, age4_lags, age2_less_lags, age3_less_lags,
                age4_plus_lags, age5_plus_lags, log_age3_lags, log_age4_lags, log_age2_less_lags, log_age3_less_lags,
                log_age4_plus_lags, log_age5_plus_lags, growth.rate_lags, growth.rate_age3_lags, growth.rate_age4_lags,
                growth.rate_age2_less_lags, growth.rate_age3_less_lags, growth.rate_age4_plus_lags, growth.rate_age5_plus_lags)


## Train/test split
all_dat_train = subset(all_dat, ReturnYear <= 2024 - test_set_size)
all_dat_test = subset(all_dat, ReturnYear > 2024 - test_set_size & ReturnYear < 2025)
all_dat_forecast = subset(all_dat, ReturnYear == 2025)




### Iterate over each model to test ###
all_res2 = foreach(i = 1:nrow(all_res), .combine = rbind, 
                   .packages = c("GPEDM")) %do% {
  
  ## Model settings                   
  E = all_res$E[i]; pop_id = all_res$Pop_id[i]; model_type = all_res$model_type[i]
  transform_type = as.character(all_res$transform_type[i])
  
  popDat_train = subset(all_dat_train, Pop_id == pop_id)
  popDat_test = subset(all_dat_test, Pop_id == pop_id)
  popDat_forecast = subset(all_dat_forecast, Pop_id == pop_id)
  
  
  ###########################################
  if(model_type == "indv_returns_byReturns"){
    
    if(transform_type == "none"){
      var_to_fit = "Total_Returns"; lagnames = colnames(return_lags)[1:E]
    }else if(transform_type == "log"){
      var_to_fit = "log_Total_Returns"; lagnames = colnames(logreturn_lags)[1:E]
    }else if(transform_type == "growth.rate"){
      var_to_fit = "growth.rate"; lagnames = colnames(return_lags)[1:E]
    }
    
    ## Fit model & make forecasts
    train_fit = fitGP(data = popDat_train, y = var_to_fit, x = lagnames, time = "ReturnYear")
    test_fit = predict_seq(train_fit, newdata = popDat_test, restart.initpars = T)
    forecast2025 = predict(test_fit, newdata = popDat_forecast)#; as.numeric(forecast2025$outsampresults['predmean'])

    if(nrow(all_res)==1){
      print(summary(test_fit))
      plot(test_fit)
    }
    
    ## Back transform fit results
    outsampres = test_fit$outsampresults

    if(transform_type == "none"){
      untr_predmean = outsampres$predmean; untr_obs = outsampres$obs
      untr_forecast2025 = as.numeric(forecast2025$outsampresults['predmean'])
    }else if(transform_type == "log"){
      untr_predmean = exp(outsampres$predmean) - log_transform_constant; untr_obs = exp(outsampres$obs) - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025$outsampresults['predmean'])) - log_transform_constant
    }else if(transform_type == "growth.rate"){
      outsampres = merge(outsampres, popDat_test[, c("ReturnYear", "Total_Returns_1")], by.x = "timestep", by.y = "ReturnYear")
      untr_predmean = exp(outsampres$predmean)*(outsampres$Total_Returns_1 + log_transform_constant) - log_transform_constant; untr_obs = exp(outsampres$obs)*(outsampres$Total_Returns_1 + log_transform_constant)  - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025$outsampresults['predmean']))*(popDat_test$Total_Returns[nrow(popDat_test)] + log_transform_constant) - log_transform_constant
    }
    
    
  #############################################
  }else if(model_type == "indv_returns_byAges"){
    
    # type 1: ages 3 & less, age 4, ages 5+
    # type 2: ages 2 & less, age 3, ages 4 +
    # type 3: ages 3 & less, ages 4 + 
    pop_age_class_type = subset(popSummary, Pop_id == pop_id)$age_class_type
    
    if(pop_age_class_type == 1){
      if(transform_type == "none"){
        var_to_fit = "Total_Returns"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }else if(transform_type == "log"){
        var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_lags)[1:E], colnames(log_age5_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        var_to_fit = "growth.rate"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 2){
      if(transform_type == "none"){
        var_to_fit = "Total_Returns"; lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age2_less_lags)[1:E], colnames(log_age3_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        var_to_fit = "growth.rate"; lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 3){
      if(transform_type == "none"){
        var_to_fit = "Total_Returns"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        var_to_fit = "growth.rate"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }
    

    ## Fit model & make forecasts
    train_fit = fitGP(data = popDat_train, y = var_to_fit, x = lagnames, time = "ReturnYear")
    test_fit = predict_seq(train_fit, newdata = popDat_test, restart.initpars = T)
    forecast2025 = predict(test_fit, newdata = popDat_forecast)
  
    if(nrow(all_res)==1){
      print(summary(test_fit))
      plot(test_fit)
    }
    
    ## Back transform fit results
    outsampres = test_fit$outsampresults
    
    if(transform_type == "none"){
      untr_predmean = outsampres$predmean; untr_obs = outsampres$obs
      untr_forecast2025 = as.numeric(forecast2025$outsampresults['predmean'])
    }else if(transform_type == "log"){
      untr_predmean = exp(outsampres$predmean) - log_transform_constant; untr_obs = exp(outsampres$obs) - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025$outsampresults['predmean'])) - log_transform_constant
    }else if(transform_type == "growth.rate"){
      outsampres = merge(outsampres, popDat_test[, c("ReturnYear", "Total_Returns_1")], by.x = "timestep", by.y = "ReturnYear")
      untr_predmean = exp(outsampres$predmean)*(outsampres$Total_Returns_1 + log_transform_constant) - log_transform_constant; untr_obs = exp(outsampres$obs)*(outsampres$Total_Returns_1 + log_transform_constant)  - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025$outsampresults['predmean']))*(popDat_test$Total_Returns[nrow(popDat_test)] + log_transform_constant) - log_transform_constant
    }
    
  ###########################################  
  }else if(model_type == "indv_ages_byAges"){
    
    # type 1: ages 3 & less, age 4, ages 5+
    # type 2: ages 2 & less, age 3, ages 4 +
    # type 3: ages 3 & less, ages 4 + 
    pop_age_class_type = subset(popSummary, Pop_id == pop_id)$age_class_type
    
    if(pop_age_class_type == 1){
      if(transform_type == "none"){
        vars_to_fit = c("age3_less", "age4", "age5_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age3_less", "log_age4", "log_age5_plus"); lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_lags)[1:E], colnames(log_age5_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age3_less", "growth.rate_age4", "growth.rate_age5_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 2){
      if(transform_type == "none"){
        vars_to_fit = c("age2_less", "age3", "age4_plus"); lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age2_less", "log_age3", "log_age4_plus"); lagnames = c(colnames(log_age2_less_lags)[1:E], colnames(log_age3_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age2_less", "growth.rate_age3", "growth.rate_age4_plus"); lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 3){
      if(transform_type == "none"){
        vars_to_fit = c("age3_less", "age4_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age3_less", "log_age4_plus"); lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age3_less", "growth.rate_age4_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }
    

    untr_predmean_class = untr_obs_class = untr_forecast2025_class = list()
    for(class_i in 1:length(vars_to_fit)){
      
      ## Fit model & make forecasts for each age class
      train_fit = fitGP(data = popDat_train, y = vars_to_fit[class_i], x = lagnames, time = "ReturnYear")
      test_fit = predict_seq(train_fit, newdata = popDat_test, restart.initpars = T)
      forecast2025 = predict(test_fit, newdata = popDat_forecast)#; as.numeric(forecast2025$outsampresults['predmean'])
      
      if(nrow(all_res)==1){
        print(summary(test_fit))
        plot(test_fit)
      }
      
      ## Back transform fit results for each age class
      outsampres = test_fit$outsampresults
      if(transform_type == "none"){
        untr_predmean_class[[class_i]] = outsampres$predmean; untr_obs_class[[class_i]] = outsampres$obs
        untr_forecast2025_class[[class_i]] = as.numeric(forecast2025$outsampresults['predmean'])
      }else if(transform_type == "log"){
        untr_predmean_class[[class_i]] = exp(outsampres$predmean) - log_transform_constant
        untr_obs_class[[class_i]] = exp(outsampres$obs) - log_transform_constant
        untr_forecast2025_class[[class_i]] = exp(as.numeric(forecast2025$outsampresults['predmean'])) - log_transform_constant
      }else if(transform_type == "growth.rate"){
        classname = strsplit(vars_to_fit[class_i], split = "growth.rate_")[[1]][2]
        outsampres = merge(outsampres, popDat_test[, c("ReturnYear", paste0(classname, "_1"))], by.x = "timestep", by.y = "ReturnYear")
        untr_predmean_class[[class_i]] = exp(outsampres$predmean)*(outsampres[, paste0(classname, "_1")] + log_transform_constant) - log_transform_constant 
        untr_obs_class[[class_i]] = exp(outsampres$obs)*(outsampres[, paste0(classname, "_1")] + log_transform_constant)  - log_transform_constant
        untr_forecast2025_class[[class_i]] = exp(as.numeric(forecast2025$outsampresults['predmean']))*(popDat_test[nrow(popDat_test), classname] + log_transform_constant) - log_transform_constant
      }
    }
    
    ## Sum results across age classes
    untr_predmean = Reduce('+', untr_predmean_class)
    untr_obs = Reduce('+', untr_obs_class)
    untr_forecast2025 = Reduce('+',untr_forecast2025_class)
    

  }
  ####################################################
  
  ## progress updates
  if(i%%20 == 0){print(paste0(i, "/", nrow(all_res)))}
  
  ## output results
  APE = abs((untr_obs - untr_predmean)/untr_obs) * 100
  R2test = getR2(obs = untr_obs, pred = untr_predmean)
  MAPEtest = mean(APE)
  medianAPEtest = median(APE)
  forecast2025 = untr_forecast2025
  APE2024 = APE[length(APE)]
  retrospec2020forecast = untr_predmean[length(untr_predmean)-4]
  retrospec2021forecast = untr_predmean[length(untr_predmean)-3]
  retrospec2022forecast = untr_predmean[length(untr_predmean)-2]
  retrospec2023forecast = untr_predmean[length(untr_predmean)-1]
  retrospec2024forecast = untr_predmean[length(untr_predmean)]
  
  modelRes = data.frame(i = i, E = E, Pop_id = pop_id, model_type = model_type, rho_model_type = NA, transform_type = transform_type, scale_type = NA,
                        MAPEtest = MAPEtest, forecast2025 = forecast2025, medianAPEtest = medianAPEtest, APE2024 = APE2024, R2test = R2test,
                        test_set_size = test_set_size, log_transform_constant = log_transform_constant, remove_data_before_year = remove_data_before_year,
                        retrospec2020forecast = retrospec2020forecast, retrospec2021forecast = retrospec2021forecast, retrospec2022forecast = retrospec2022forecast, 
                        retrospec2023forecast = retrospec2023forecast, retrospec2024forecast = retrospec2024forecast)
  
  modelRes
  
  
}


if(save_output == T){
  write.csv(all_res2, file = paste0("results/run_results_", format(Sys.time(), "%Y%b%d_%H%M%S"), ".csv"))
}


### Plot/summarize results ###

if(nrow(all_res)>1){
  ### Identify best model for each river
  popBestRes = aggregate(all_res2$MAPEtest, by = list(all_res2$Pop_id), min); colnames(popBestRes) = c("Pop_id" ,"bestMAPE")
  popBestRes = merge(popBestRes, popSummary, by = "Pop_id")
  
  print(summary(popBestRes$bestMAPE))
  print(popBestRes)
  
  popBestResmedian = aggregate(all_res2$medianAPEtest, by = list(all_res2$Pop_id), min); colnames(popBestResmedian) = c("Pop_id" ,"bestMedianAPE")
  popBestResmedian = merge(popBestResmedian, popSummary, by = "Pop_id")
  popBestResmedian = merge(popBestResmedian, popBestRes, by = c("Pop_id", "River", "System"))
  popBestResmedian = popBestResmedian[order(popBestResmedian$Pop_id), ]
  popBestResmedian$bestMeanAPE = popBestResmedian$bestMAPE
  print(popBestResmedian[, c("Pop_id", "System", "River", "bestMeanAPE", "bestMedianAPE")])
  
}
