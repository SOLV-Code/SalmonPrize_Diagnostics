### This script is used to process the provided data for fitting with GPEDM
## NOTE: in the following code, the age classes are named incorrectly (off by one year): "age 2" should be age 3,
##       "age 4 or greater" should be age 5 or greater, and so forth. This naming error does not affect model performance or results


library(data.table); library(this.path)
setwd(this.path::here())

log_transform_constant = 1 #log(x + constant), to deal with 0s


### Read in data
all_dat = read.csv(file = "data/Combined_Return_Bristol_Columbia_Fraser.csv")


## Process age classes (see above note about age classes being named incorrectly...)
all_dat$age1 = all_dat$AgeClass_0.1
all_dat$age2 = all_dat$AgeClass_0.2 + all_dat$AgeClass_1.1
all_dat$age3 = all_dat$AgeClass_0.3 + all_dat$AgeClass_1.2 + all_dat$AgeClass_2.1
all_dat$age4 = all_dat$AgeClass_0.4 + all_dat$AgeClass_1.3 + all_dat$AgeClass_2.2 + all_dat$AgeClass_3.1
all_dat$age5 = all_dat$AgeClass_0.5 + all_dat$AgeClass_1.4 + all_dat$AgeClass_2.3 + all_dat$AgeClass_3.2
all_dat$age6 = all_dat$AgeClass_1.5 + all_dat$AgeClass_2.4 + all_dat$AgeClass_3.3
all_dat$age7 = all_dat$AgeClass_3.4

all_dat$age2_less = all_dat$age1 + all_dat$age2
all_dat$age3_less = all_dat$age2_less + all_dat$age3
all_dat$age5_plus = all_dat$age5 + all_dat$age6 + all_dat$age7
all_dat$age4_plus = all_dat$age4 + all_dat$age5_plus


### identify most relevant age class groupings by river
#only include separate age class if it makes up at least XX% of returns and has fewer than XX% zero observations; otherwise, group it with another age class
#ageclass_freq_cutoff = 0.02; zero_freq_cutoff = .4
#for(river in unique(all_dat$River)){
#  popDat = subset(all_dat, River == river & Total_Returns > 0)
#  ageclass_freq = popDat[, c("age1", "age2", "age3", "age4", "age5", "age6", "age7")]/popDat$Total_Returns
#  mean_ageclass_freq = colSums(ageclass_freq)/nrow(ageclass_freq)
#  zero_freq = popDat[, c("age1", "age2", "age3", "age4", "age5", "age6", "age7")] < 1
#  mean_zero_freq = colSums(zero_freq)/nrow(zero_freq)
#  popAgeSummary = as.data.frame(cbind(mean_ageclass_freq, mean_zero_freq))
#  popAgeSummary2 = subset(popAgeSummary, mean_ageclass_freq > ageclass_freq_cutoff & mean_zero_freq < zero_freq_cutoff)
#  print(paste0(river, ":", paste0(rownames(popAgeSummary2), collapse = ", ")  )); 
#  print(popAgeSummary)
#}


# type 1: ages 3 & less, age 4, ages 5 +
# type 2: ages 2 & less, age 3, ages 4 +
# type 3: ages 3 & less, ages 4 + 
#age_class_type = data.frame(River = c("Alagnak", "Egegik", "Igushik", "Kvichak", "Naknek", "Nushagak", "Ugashik", "Wood", 
#                                      "Bonneville Lock & Dam", "Chilko", "Late Stuart", "Quesnel", "Raft", "Stellako"),
#                            age_class_type = c(rep(1, 8), rep(2, 4), rep(3, 2)))

## Although age 2 & less returns are very small in Raft & Stellako, to make fitting hierarchical models for the Fraser simpler,
##    we do include age 2 & less as an age class for these rivers
age_class_type = data.frame(River = c("Alagnak", "Egegik", "Igushik", "Kvichak", "Naknek", "Nushagak", "Ugashik", "Wood", 
                                      "Bonneville Lock & Dam", "Chilko", "Late Stuart", "Quesnel", "Raft", "Stellako"),
                            age_class_type = c(rep(1, 8), rep(2, 6)))



## Add in blank rows for 2025 for each pop to make predictions
dat2025 = subset(all_dat, ReturnYear == 2024); dat2025$ReturnYear = 2025
dat2025[, c(5:ncol(dat2025))] = NA
all_dat = rbind(all_dat, dat2025)
all_dat = all_dat[order(all_dat$X, all_dat$ReturnYear),]
all_dat$X = 1:nrow(all_dat)

## Summary information for each river
popSummary = all_dat[!duplicated(all_dat$River),  c("System", "River", "ReturnYear")]; colnames(popSummary)[3] = "yearStart"
popSummary$Pop_id = 1:nrow(popSummary)

nGroupYears = aggregate(all_dat$ReturnYear, by = list(all_dat$River), length); colnames(nGroupYears) = c("River", "nYearsData")
nGroupYears$nYearsData = nGroupYears$nYearsData - 1 #2025 doesn't count
popSummary = merge(x = popSummary, y = nGroupYears, by = "River", sort = F)
popSummary = merge(x = popSummary, y = age_class_type, by = "River", sort = F)
popSummary$maxE = floor(sqrt(popSummary$nYearsData))

all_dat = merge(all_dat, popSummary, by = c("River", "System"), sort = F)
all_dat = all_dat[order(all_dat$X),]

## transformed data
all_dat$log_Total_Returns = log(all_dat$Total_Returns + log_transform_constant)
all_dat$log_age3 = log(all_dat$age3 + log_transform_constant)
all_dat$log_age4 = log(all_dat$age4 + log_transform_constant)
all_dat$log_age2_less = log(all_dat$age2_less + log_transform_constant)
all_dat$log_age3_less = log(all_dat$age3_less + log_transform_constant)
all_dat$log_age4_plus = log(all_dat$age4_plus + log_transform_constant)
all_dat$log_age5_plus = log(all_dat$age5_plus + log_transform_constant)
all_dat$growth.rate = data.table::data.table(all_dat)[, growth.rate := log((Total_Returns + log_transform_constant)/(shift(Total_Returns) + log_transform_constant)), by = Pop_id]$growth.rate
all_dat$growth.rate_age3 = data.table::data.table(all_dat)[, growth.rate_age3 := log((age3 + log_transform_constant)/(shift(age3) + log_transform_constant)), by = Pop_id]$growth.rate_age3
all_dat$growth.rate_age4 = data.table::data.table(all_dat)[, growth.rate_age4 := log((age4 + log_transform_constant)/(shift(age4) + log_transform_constant)), by = Pop_id]$growth.rate_age4
all_dat$growth.rate_age2_less = data.table::data.table(all_dat)[, growth.rate_age2_less := log((age2_less + log_transform_constant)/(shift(age2_less) + log_transform_constant)), by = Pop_id]$growth.rate_age2_less
all_dat$growth.rate_age3_less = data.table::data.table(all_dat)[, growth.rate_age3_less := log((age3_less + log_transform_constant)/(shift(age3_less) + log_transform_constant)), by = Pop_id]$growth.rate_age3_less
all_dat$growth.rate_age4_plus = data.table::data.table(all_dat)[, growth.rate_age4_plus := log((age4_plus + log_transform_constant)/(shift(age4_plus) + log_transform_constant)), by = Pop_id]$growth.rate_age4_plus
all_dat$growth.rate_age5_plus = data.table::data.table(all_dat)[, growth.rate_age5_plus := log((age5_plus + log_transform_constant)/(shift(age5_plus) + log_transform_constant)), by = Pop_id]$growth.rate_age5_plus
all_dat$log_transform_constant = log_transform_constant



## Save data
write.csv(all_dat, file = "data/processed_data.csv")






#ggplot(subset(all_dat, River == "Chilko")) + geom_line(aes(x = ReturnYear, y = Total_Returns))
#ggplot(subset(all_dat, River == "Egegik")) + geom_line(aes(x = ReturnYear, y = age4)) +
#  geom_line(aes(x = ReturnYear, y = AgeClass_0.4), color = 'red') + 
#  geom_line(aes(x = ReturnYear, y = AgeClass_1.3), color = 'blue') +
#  geom_line(aes(x = ReturnYear, y = AgeClass_2.2), color = 'green') + 
#  geom_line(aes(x = ReturnYear, y = AgeClass_3.1), color = 'yellow') 