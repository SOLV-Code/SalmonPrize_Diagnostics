### This script fits hierarchical GPEDM model(s) for the Fraser River and Bristol Bay systems
## NOTE: in the following code, the age classes are named incorrectly (off by one year): "age 2" should be age 3,
##       "age 4 or greater" should be age 5 or greater, and so forth. This naming error does not affect model performance or results


library(GPEDM); library(ggplot2); library(foreach); library(this.path)
## GPEDM package: https://tanyalrogers.github.io/GPEDM/
setwd(this.path::here())

### Settings ###

## Primary model settings. Can include multiple options in a vector, and all combinations of model settings will be fit
# E: embedding dimension, aka how many years back should the lags of returns go? Can be 1, ..., 8
# model_type: the general structure of the model. Options include "hier_returns_byReturns", "hier_returns_byAges", "hier_ages_byAges"
#       hier_returns_byReturns: lags of total returns are used to predict total returns
#       hier_returns_byAges: lags of age-structured returns are used to predict total returns
#       hier_returns_byReturns: lags of age-structured returns are used to predict age-structured returns. Forecasts for each 
#                               age class are then summed to get a forecast of total returns.
# transform: what data transformation should be applied? Options include "none", "log", "growth.rate" (i.e., ln[x_{t}/x_{t-1}]) 
# rho_model_type: should the dynamic correlation parameter rho be fixed to 1 ("fixed"), or estimated for each pair of rivers ("matrix")?
# scale_type: should "local" or "global" scaling be used in the hierarchical models?
# system: For which system should we fit hierarchical models? Options include "Bristol Bay", "Fraser River" 

E_to_test = 1:8
model_type_to_test = c("hier_returns_byReturns", "hier_returns_byAges", "hier_ages_byAges") 
transform_to_test = c("none", "log", "growth.rate") 
rho_model_type_to_test = c("fixed", "matrix")
scale_type_to_test = c("local", "global")
systems_to_test = c("Bristol Bay", "Fraser River")

## other settings
test_set_size = 10  #How many years to include in the test set. More years will take longer
remove_data_before_year = 1952 #throw out data before this year
save_output = T  # save csv file of model performance results?


### Read in Data ###
all_dat = read.csv("data/processed_data.csv")

#Throw out earlier data?
all_dat = subset(all_dat, ReturnYear >= remove_data_before_year) 

# Separate hierarchical models for each system
split_vec = systems_to_test
all_dat$split_col = all_dat$System

# Summary information for each river
popSummary = all_dat[!duplicated(all_dat$River),  c("System", "River", "Pop_id", "age_class_type", "yearStart", "nYearsData", "maxE")]

log_transform_constant = all_dat$log_transform_constant[1]


## Results data frame
all_res = expand.grid(E = E_to_test, model_type = model_type_to_test, rho_model_type = rho_model_type_to_test,
                      transform_type = transform_to_test, scale_type = scale_type_to_test, hier_split = split_vec)
all_res$runID = 1:nrow(all_res)

## Make lags
return_lags = makelags(all_dat, y = "Total_Returns", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
logreturn_lags = makelags(all_dat, y = "log_Total_Returns", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age3_lags = makelags(all_dat, y = "age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age4_lags = makelags(all_dat, y = "age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age2_less_lags = makelags(all_dat, y = "age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age3_less_lags = makelags(all_dat, y = "age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age4_plus_lags = makelags(all_dat, y = "age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
age5_plus_lags = makelags(all_dat, y = "age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age3_lags = makelags(all_dat, y = "log_age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age4_lags = makelags(all_dat, y = "log_age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age2_less_lags = makelags(all_dat, y = "log_age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age3_less_lags = makelags(all_dat, y = "log_age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age4_plus_lags = makelags(all_dat, y = "log_age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
log_age5_plus_lags = makelags(all_dat, y = "log_age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_lags = makelags(all_dat, y = "growth.rate", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age3_lags = makelags(all_dat, y = "growth.rate_age3", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age4_lags = makelags(all_dat, y = "growth.rate_age4", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age2_less_lags = makelags(all_dat, y = "growth.rate_age2_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age3_less_lags = makelags(all_dat, y = "growth.rate_age3_less", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age4_plus_lags = makelags(all_dat, y = "growth.rate_age4_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")
growth.rate_age5_plus_lags = makelags(all_dat, y = "growth.rate_age5_plus", E = max(popSummary$maxE), tau = 1, pop = "Pop_id")


all_dat = cbind(all_dat, return_lags, logreturn_lags, age3_lags, age4_lags, age2_less_lags, age3_less_lags,
                age4_plus_lags, age5_plus_lags, log_age3_lags, log_age4_lags, log_age2_less_lags, log_age3_less_lags,
                log_age4_plus_lags, log_age5_plus_lags, growth.rate_lags, growth.rate_age3_lags, growth.rate_age4_lags,
                growth.rate_age2_less_lags, growth.rate_age3_less_lags, growth.rate_age4_plus_lags, growth.rate_age5_plus_lags)


## Train/test split
all_dat_train = subset(all_dat, ReturnYear <= 2024 - test_set_size)
all_dat_test = subset(all_dat, ReturnYear > 2024 - test_set_size & ReturnYear < 2025)
all_dat_forecast = subset(all_dat, ReturnYear == 2025)




### Iterate over each model to test ###
all_res2 = foreach(i = 1:nrow(all_res), .combine = rbind, 
                   .packages = c("GPEDM")) %do% {
  
  ## Model settings                    
  E = all_res$E[i]; model_type = all_res$model_type[i]; rho_model_type = all_res$rho_model_type[i]
  transform_type = as.character(all_res$transform_type[i]); scale_type = as.character(all_res$scale_type[i])
  hier_split = as.character(all_res$hier_split[i])
  pop_age_class_type = ifelse(hier_split == "Fraser River", 2, 1)
  
  popDat_train = subset(all_dat_train, split_col == hier_split)
  popDat_test = subset(all_dat_test, split_col == hier_split)
  popDat_forecast = subset(all_dat_forecast, split_col == hier_split)
  
  
  ###########################################
  if(model_type == "hier_returns_byReturns" | model_type == "hier_returns_byAges"){
    
    if(model_type == "hier_returns_byReturns"){
      if(transform_type == "none"){
        var_to_fit = "Total_Returns"; lagnames = colnames(return_lags)[1:E]
      }else if(transform_type == "log"){
        var_to_fit = "log_Total_Returns"; lagnames = colnames(logreturn_lags)[1:E]
      }else if(transform_type == "growth.rate"){
        var_to_fit = "growth.rate"; lagnames = colnames(return_lags)[1:E]
      }
    }else if(model_type == "hier_returns_byAges"){
      
      if(pop_age_class_type == 1){
        if(transform_type == "none"){
          var_to_fit = "Total_Returns"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
        }else if(transform_type == "log"){
          var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_lags)[1:E], colnames(log_age5_plus_lags)[1:E])
        }else if(transform_type == "growth.rate"){
          var_to_fit = "growth.rate"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
        }
      }else if(pop_age_class_type == 2){
        if(transform_type == "none"){
          var_to_fit = "Total_Returns"; lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
        }else if(transform_type == "log"){
          var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age2_less_lags)[1:E], colnames(log_age3_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
        }else if(transform_type == "growth.rate"){
          var_to_fit = "growth.rate"; lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
        }
      }else if(pop_age_class_type == 3){
        if(transform_type == "none"){
          var_to_fit = "Total_Returns"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
        }else if(transform_type == "log"){
          var_to_fit = "log_Total_Returns"; lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
        }else if(transform_type == "growth.rate"){
          var_to_fit = "growth.rate"; lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
        }
      }
      
    }
    
    ## Fit model & make forecasts
    if(rho_model_type == "fixed"){
      train_fit = fitGP(data = popDat_train, y = var_to_fit,  pop = "Pop_id", x = lagnames, time = "ReturnYear", scaling = scale_type,  rhofixed = 0.9999)
    }else if(rho_model_type == "matrix"){
      Rhomat = getrhomatrix(popDat_train, y = var_to_fit, x = lagnames, 
                            pop = "Pop_id", time = "ReturnYear", scaling = scale_type)
      train_fit = fitGP(data = popDat_train, y = var_to_fit,  pop = "Pop_id", x = lagnames, time = "ReturnYear", scaling = scale_type, rhomatrix = posdef(Rhomat))
    }
    
    test_fit = predict_seq(train_fit, newdata = popDat_test, restart.initpars = T)
    forecast2025 = predict(test_fit, newdata = popDat_forecast)#; as.numeric(forecast2025$outsampresults['predmean'])

    if(nrow(all_res)==1){
      print(summary(test_fit))
      plot(test_fit)
    }
    
    ## get results for each population and back transform them
    MAPE_bypop = numeric(0); medianAPE_bypop = numeric(0); forecast2025_bypop = numeric(0); R2_bypop = numeric(0)
    retrospec2020forecast_bypop = retrospec2021forecast_bypop = retrospec2022forecast_bypop = retrospec2023forecast_bypop =retrospec2024forecast_bypop = numeric(0)
    
    Pop_to_test = unique(popDat_train$Pop_id)
    for(pop_i in Pop_to_test){
      outsampres = subset(test_fit$outsampresults, pop == pop_i)
      forecast2025_pop = subset(forecast2025$outsampresults, pop == pop_i)
    if(transform_type == "none"){
      untr_predmean = outsampres$predmean; untr_obs = outsampres$obs
      untr_forecast2025 = as.numeric(forecast2025_pop['predmean'])
    }else if(transform_type == "log"){
      untr_predmean = exp(outsampres$predmean) - log_transform_constant; untr_obs = exp(outsampres$obs) - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025_pop['predmean'])) - log_transform_constant
    }else if(transform_type == "growth.rate"){
      outsampres = merge(outsampres, subset(popDat_test, Pop_id == pop_i)[, c("ReturnYear", "Total_Returns_1")], by.x = "timestep", by.y = "ReturnYear")
      untr_predmean = exp(outsampres$predmean)*(outsampres$Total_Returns_1 + log_transform_constant) - log_transform_constant; untr_obs = exp(outsampres$obs)*(outsampres$Total_Returns_1 + log_transform_constant)  - log_transform_constant
      untr_forecast2025 = exp(as.numeric(forecast2025_pop['predmean']))*(subset(popDat_test, Pop_id == pop_i)$Total_Returns[nrow(subset(popDat_test, Pop_id == pop_i))] + log_transform_constant) - log_transform_constant
    }
      ## Calculate model performance for each population
      APE = abs((untr_obs - untr_predmean)/untr_obs) * 100
      
      MAPE_bypop = c(MAPE_bypop, mean(APE))
      medianAPE_bypop = c(medianAPE_bypop, median(APE))
      forecast2025_bypop = c(forecast2025_bypop, untr_forecast2025)
      R2_bypop = c(R2_bypop, getR2(obs = untr_obs, pred = untr_predmean))
      
      retrospec2020forecast_bypop = c(retrospec2020forecast_bypop, untr_predmean[length(untr_predmean)-4])
      retrospec2021forecast_bypop = c(retrospec2021forecast_bypop, untr_predmean[length(untr_predmean)-3])
      retrospec2022forecast_bypop = c(retrospec2022forecast_bypop, untr_predmean[length(untr_predmean)-2])
      retrospec2023forecast_bypop = c(retrospec2023forecast_bypop, untr_predmean[length(untr_predmean)-1])
      retrospec2024forecast_bypop = c(retrospec2024forecast_bypop, untr_predmean[length(untr_predmean)])
      
    }
    
  #############################################
  }else if(model_type == "hier_ages_byAges"){
    
    
    if(pop_age_class_type == 1){
      if(transform_type == "none"){
        vars_to_fit = c("age3_less", "age4", "age5_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age3_less", "log_age4", "log_age5_plus"); lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_lags)[1:E], colnames(log_age5_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age3_less", "growth.rate_age4", "growth.rate_age5_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_lags)[1:E], colnames(age5_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 2){
      if(transform_type == "none"){
        vars_to_fit = c("age2_less", "age3", "age4_plus"); lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age2_less", "log_age3", "log_age4_plus"); lagnames = c(colnames(log_age2_less_lags)[1:E], colnames(log_age3_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age2_less", "growth.rate_age3", "growth.rate_age4_plus"); lagnames = c(colnames(age2_less_lags)[1:E], colnames(age3_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }else if(pop_age_class_type == 3){
      if(transform_type == "none"){
        vars_to_fit = c("age3_less", "age4_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }else if(transform_type == "log"){
        vars_to_fit = c("log_age3_less", "log_age4_plus"); lagnames = c(colnames(log_age3_less_lags)[1:E], colnames(log_age4_plus_lags)[1:E])
      }else if(transform_type == "growth.rate"){
        vars_to_fit = c("growth.rate_age3_less", "growth.rate_age4_plus"); lagnames = c(colnames(age3_less_lags)[1:E], colnames(age4_plus_lags)[1:E])
      }
    }
    
    
    outsampres_list = list(); forecast2025_list = list()
    for(class_i in 1:length(vars_to_fit)){
      
      ## Fit model & make forecasts for each age class
      if(rho_model_type == "fixed"){
        train_fit = fitGP(data = popDat_train, y = vars_to_fit[class_i],  pop = "Pop_id", x = lagnames, time = "ReturnYear", scaling = scale_type,  rhofixed = 0.9999)
      }else if(rho_model_type == "matrix"){
        Rhomat = getrhomatrix(popDat_train, y = vars_to_fit[class_i], x = lagnames, 
                              pop = "Pop_id", time = "ReturnYear", scaling = scale_type)
        train_fit = fitGP(data = popDat_train, y = vars_to_fit[class_i],  pop = "Pop_id", x = lagnames, time = "ReturnYear", scaling = scale_type, rhomatrix = posdef(Rhomat))
      }
      
      test_fit = predict_seq(train_fit, newdata = popDat_test, restart.initpars = T)
      forecast2025_list[[class_i]] = predict(test_fit, newdata = popDat_forecast)#; as.numeric(forecast2025$outsampresults['predmean'])
      outsampres_list[[class_i]] = test_fit$outsampresults
      
      if(nrow(all_res)==1){
        print(summary(test_fit))
        plot(test_fit)
      }
    }   
    
    ## get results for each population and age class, and back transform them
    MAPE_bypop = numeric(0); medianAPE_bypop = numeric(0); forecast2025_bypop = numeric(0); R2_bypop = numeric(0)
    retrospec2020forecast_bypop = retrospec2021forecast_bypop = retrospec2022forecast_bypop = retrospec2023forecast_bypop =retrospec2024forecast_bypop = numeric(0)
    
    Pop_to_test = unique(popDat_train$Pop_id)
    for(pop_i in Pop_to_test){
      untr_predmean_class = untr_obs_class = untr_forecast2025_class = list()
      for(class_i in 1:length(vars_to_fit)){  
        outsampres = subset(outsampres_list[[class_i]], pop == pop_i)
        forecast2025 = subset(forecast2025_list[[class_i]]$outsampresults, pop == pop_i)
        if(transform_type == "none"){
          untr_predmean_class[[class_i]] = outsampres$predmean; untr_obs_class[[class_i]] = outsampres$obs
          untr_forecast2025_class[[class_i]] = as.numeric(forecast2025['predmean'])
        }else if(transform_type == "log"){
          untr_predmean_class[[class_i]] = exp(outsampres$predmean) - log_transform_constant
          untr_obs_class[[class_i]] = exp(outsampres$obs) - log_transform_constant
          untr_forecast2025_class[[class_i]] = exp(as.numeric(forecast2025['predmean'])) - log_transform_constant
        }else if(transform_type == "growth.rate"){
          classname = strsplit(vars_to_fit[class_i], split = "growth.rate_")[[1]][2]
          outsampres = merge(outsampres, subset(popDat_test, Pop_id == pop_i)[, c("ReturnYear", paste0(classname, "_1"))], by.x = "timestep", by.y = "ReturnYear")
          untr_predmean_class[[class_i]] = exp(outsampres$predmean)*(outsampres[, paste0(classname, "_1")] + log_transform_constant) - log_transform_constant 
          untr_obs_class[[class_i]] = exp(outsampres$obs)*(outsampres[, paste0(classname, "_1")] + log_transform_constant)  - log_transform_constant
          untr_forecast2025_class[[class_i]] = exp(as.numeric(forecast2025['predmean']))*(subset(popDat_test, Pop_id == pop_i)[nrow(subset(popDat_test, Pop_id == pop_i)), classname] + log_transform_constant) - log_transform_constant
        }
      }
      ## Sum results across age classes
      untr_predmean = Reduce('+', untr_predmean_class)
      untr_obs = Reduce('+', untr_obs_class)
      untr_forecast2025 = Reduce('+',untr_forecast2025_class)
      
      ## Calculate model performance for each population
      APE = abs((untr_obs - untr_predmean)/untr_obs) * 100
      
      MAPE_bypop = c(MAPE_bypop, mean(APE))
      medianAPE_bypop = c(medianAPE_bypop, median(APE))
      forecast2025_bypop = c(forecast2025_bypop, untr_forecast2025)
      R2_bypop = c(R2_bypop, getR2(obs = untr_obs, pred = untr_predmean))
      
      retrospec2020forecast_bypop = c(retrospec2020forecast_bypop, untr_predmean[length(untr_predmean)-4])
      retrospec2021forecast_bypop = c(retrospec2021forecast_bypop, untr_predmean[length(untr_predmean)-3])
      retrospec2022forecast_bypop = c(retrospec2022forecast_bypop, untr_predmean[length(untr_predmean)-2])
      retrospec2023forecast_bypop = c(retrospec2023forecast_bypop, untr_predmean[length(untr_predmean)-1])
      retrospec2024forecast_bypop = c(retrospec2024forecast_bypop, untr_predmean[length(untr_predmean)])
    }
    
    
    
  }
  ####################################################
  
  ## progress updates
  print(paste0(i, "/", nrow(all_res)))
  
  ## output results
  modelRes = data.frame(E = E, Pop_id = Pop_to_test, model_type = model_type, rho_model_type = rho_model_type, transform_type = transform_type, scale_type = scale_type,
                        MAPEtest = MAPE_bypop, forecast2025 = forecast2025_bypop, medianAPEtest = medianAPE_bypop, R2test = R2_bypop,
                        test_set_size = test_set_size, log_transform_constant = log_transform_constant, remove_data_before_year = remove_data_before_year,
                        retrospec2020forecast = retrospec2020forecast_bypop, retrospec2021forecast = retrospec2021forecast_bypop, retrospec2022forecast = retrospec2022forecast_bypop, 
                        retrospec2023forecast = retrospec2023forecast_bypop, retrospec2024forecast = retrospec2024forecast_bypop)
  
  modelRes
  
  
}


if(save_output == T){
  write.csv(all_res2, file = paste0("results/run_results_", format(Sys.time(), "%Y%b%d_%H%M%S"), ".csv"))
}


### Plot/summarize results ###

if(nrow(all_res)>1){
  ### Identify best model for each river
  popBestRes = aggregate(all_res2$MAPEtest, by = list(all_res2$Pop_id), min); colnames(popBestRes) = c("Pop_id" ,"bestMAPE")
  popBestRes = merge(popBestRes, popSummary, by = "Pop_id")
  
  print(summary(popBestRes$bestMAPE))
  print(popBestRes)
  
  popBestResmedian = aggregate(all_res2$medianAPEtest, by = list(all_res2$Pop_id), min); colnames(popBestResmedian) = c("Pop_id" ,"bestMedianAPE")
  popBestResmedian = merge(popBestResmedian, popSummary, by = "Pop_id")
  popBestResmedian = merge(popBestResmedian, popBestRes, by = c("Pop_id", "River", "System"))
  popBestResmedian = popBestResmedian[order(popBestResmedian$Pop_id), ]
  popBestResmedian$bestMeanAPE = popBestResmedian$bestMAPE
  print(popBestResmedian[, c("Pop_id", "System", "River", "bestMeanAPE", "bestMedianAPE")])
  
}


